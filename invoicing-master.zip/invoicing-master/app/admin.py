from django.contrib import admin
from .models import invoice_owner

admin.site.register(invoice_owner)